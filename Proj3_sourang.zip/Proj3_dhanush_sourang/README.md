# Project 3
## Authors
dallam
UID- 119390320


Sourang
UID-119074947
## Dependencies
- Numpy
- copy
- pyplot
- queue
- time
- pygame
- matplotlib
- math
- sorted list
- 
## Instructions:
- unzip Proj3_dhanush_sourang
- open the terminal in the folder location and run the following command
```
python3 a_star_dhanush_sourang.py
```
-in the folder Proj3_dhanush_sourang, there should be a read me, a video recording and a main python script named a_star_dhanush_sourang.py


